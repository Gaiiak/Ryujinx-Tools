using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;

namespace GaiiakGameRyujinxTools
{
    public partial class SelectVersionWindow : Window
    {
        public class ArchiveItem
        {
            public string FileName { get; set; } = "";
            public string FullPath { get; set; } = "";
        }

        public string? SelectedArchivePath { get; private set; }

        public SelectVersionWindow(IEnumerable<string> archivePaths)
        {
            InitializeComponent();

            var items = archivePaths
                .OrderByDescending(p => Path.GetFileName(p))
                .Select(p => new ArchiveItem
                {
                    FileName = Path.GetFileName(p),
                    FullPath = p
                })
                .ToList();

            ListArchives.ItemsSource = items;
            if (items.Count > 0)
                ListArchives.SelectedIndex = 0;
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            if (ListArchives.SelectedItem is ArchiveItem selected)
            {
                SelectedArchivePath = selected.FullPath;
                DialogResult = true;
                Close();
            }
            else
            {
                MessageBox.Show(
                    "Veuillez sélectionner une archive.",
                    "Information",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (ListArchives.SelectedItem is not ArchiveItem selected)
            {
                MessageBox.Show(
                    "Veuillez sélectionner une archive à supprimer.",
                    "Information",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
                return;
            }

            var confirm = MessageBox.Show(
                $"Supprimer l'archive :\n\n{selected.FileName} ?",
                "Confirmation de suppression",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (confirm != MessageBoxResult.Yes)
                return;

            try
            {
                if (File.Exists(selected.FullPath))
                    File.Delete(selected.FullPath);
            }
            catch (IOException ioEx)
            {
                MessageBox.Show(
                    "Impossible de supprimer le fichier :\n" + ioEx.Message,
                    "Erreur",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                return;
            }

            var remaining = ListArchives.ItemsSource!
                .Cast<ArchiveItem>()
                .Where(a => a.FullPath != selected.FullPath)
                .ToList();

            if (remaining.Count == 0)
            {
                MessageBox.Show(
                    "Il n'y a plus d'archives disponibles.",
                    "Information",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
                SelectedArchivePath = null;
                DialogResult = false;
                Close();
                return;
            }

            ListArchives.ItemsSource = remaining;
            ListArchives.SelectedIndex = 0;
        }
    }
}
