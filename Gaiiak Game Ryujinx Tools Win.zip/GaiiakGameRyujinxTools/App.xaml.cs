﻿using System.Windows;

namespace GaiiakGameRyujinxTools
{
    public partial class App : Application
    {
    }
}
