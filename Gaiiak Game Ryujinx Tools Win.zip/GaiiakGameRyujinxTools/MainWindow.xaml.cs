﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using WinForms = System.Windows.Forms;
using MessageBox = System.Windows.MessageBox;

namespace GaiiakGameRyujinxTools
{
    public partial class MainWindow : Window
    {
        private readonly string _appBaseDir;
        private readonly string _configDir;
        private readonly string _kitsDir;
        private readonly string _versionsDir;
        private readonly string _tempDir;
        private readonly string _configFilePath;
        private readonly HttpClient _httpClient = new HttpClient();

        private const string CanaryReleasesApiUrl =
            "https://git.ryujinx.app/api/v4/projects/68/releases";

        private const string KitDownloadUrl =
            "https://www.dropbox.com/scl/fi/rdvj8r8xsds0u52l289w2/Firmware-21.zip?rlkey=evdngte2we0xgfbpje6etfdyo&st=b7wwzu8d&dl=1";

        // --- API Win32 pour centrer la fenêtre Ryujinx ---
        [DllImport("user32.dll")]
        private static extern bool SetWindowPos(
            IntPtr hWnd, IntPtr hWndInsertAfter,
            int X, int Y, int cx, int cy, uint uFlags);

        private const uint SWP_NOSIZE = 0x0001;
        private const uint SWP_NOZORDER = 0x0004;
        private static readonly IntPtr HWND_TOP = IntPtr.Zero;

        private void CenterWindow(Process proc)
        {
            var handle = proc.MainWindowHandle;
            if (handle == IntPtr.Zero) return;

            var screen = SystemParameters.WorkArea;
            int width = 1280;
            int height = 720;

            int posX = (int)(screen.Width - width) / 2;
            int posY = (int)(screen.Height - height) / 2;

            SetWindowPos(handle, HWND_TOP, posX, posY, width, height,
                SWP_NOSIZE | SWP_NOZORDER);
        }

        private async Task CenterProcessWindowAsync(Process proc)
        {
            const int timeoutMs = 5000;   // 5 secondes max
            int waited = 0;

            while (proc.MainWindowHandle == IntPtr.Zero &&
                   !proc.HasExited &&
                   waited < timeoutMs)
            {
                await Task.Delay(200);
                waited += 200;
                proc.Refresh();
            }

            if (proc.MainWindowHandle != IntPtr.Zero)
            {
                CenterWindow(proc);
            }
        }

        public MainWindow()
        {
            InitializeComponent();

            _appBaseDir = AppDomain.CurrentDomain.BaseDirectory;
            _configDir = Path.Combine(_appBaseDir, "Configuration");
            _kitsDir = Path.Combine(_appBaseDir, "Kits");
            _versionsDir = Path.Combine(_appBaseDir, "Versions Précédentes");
            _tempDir = Path.Combine(_appBaseDir, "Temp");
            _configFilePath = Path.Combine(_configDir, "Config.txt");

            Loaded += MainWindow_Loaded;
        }

        private async void MainWindow_Loaded(object? sender, RoutedEventArgs e)
        {
            try
            {
                InitDirectoriesAndConfig();
                await EnsureInstallPathAsync();
                AppendLog("Application prête.");
            }
            catch (Exception ex)
            {
                AppendLog($"Erreur au lancement : {ex.Message}");
                MessageBox.Show(ex.Message, "Erreur",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        #region Initialisation

        private void InitDirectoriesAndConfig()
        {
            Directory.CreateDirectory(_configDir);
            Directory.CreateDirectory(_kitsDir);
            Directory.CreateDirectory(_versionsDir);
            Directory.CreateDirectory(_tempDir);

            if (!File.Exists(_configFilePath))
                File.WriteAllText(_configFilePath, "");
        }

        private async Task EnsureInstallPathAsync()
        {
            var path = await ReadInstallPathAsync();
            if (string.IsNullOrWhiteSpace(path) || !Directory.Exists(path))
            {
                AppendLog("Chemin d'installation non configuré. Demande à l'utilisateur...");
                SelectInstallPathWithDialog();
            }
            else
            {
                AppendLog($"Chemin actuel : {path}");
            }
        }

        private Task<string> ReadInstallPathAsync()
        {
            if (!File.Exists(_configFilePath))
                return Task.FromResult(string.Empty);

            return Task.FromResult(File.ReadAllText(_configFilePath).Trim());
        }

        private void SaveInstallPath(string path)
        {
            File.WriteAllText(_configFilePath, path);
            AppendLog($"Chemin d'installation sauvegardé : {path}");
        }

        private void SelectInstallPathWithDialog()
        {
            using var dialog = new WinForms.FolderBrowserDialog
            {
                Description = "Sélectionnez le répertoire où installer Ryujinx",
                ShowNewFolderButton = true
            };

            if (dialog.ShowDialog() == WinForms.DialogResult.OK &&
                !string.IsNullOrWhiteSpace(dialog.SelectedPath))
            {
                SaveInstallPath(dialog.SelectedPath);
            }
            else
            {
                MessageBox.Show(
                    "L'application ne peut pas fonctionner sans dossier d'installation.",
                    "Information", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private async Task<string> GetInstallPathOrAskAsync()
        {
            var path = await ReadInstallPathAsync();
            if (string.IsNullOrWhiteSpace(path) || !Directory.Exists(path))
            {
                SelectInstallPathWithDialog();
                path = await ReadInstallPathAsync();
            }

            if (string.IsNullOrWhiteSpace(path))
                throw new Exception("Aucun chemin valide.");

            return path;
        }

        #endregion

        #region Utilitaires UI

        private void AppendLog(string msg)
        {
            Dispatcher.Invoke(() =>
            {
                TxtLog.AppendText($"[{DateTime.Now:HH:mm:ss}] {msg}{Environment.NewLine}");
                TxtLog.ScrollToEnd();
            });
        }

        private void ShowProgressBar()
        {
            Dispatcher.Invoke(() =>
            {
                ProgressPanel.Visibility = Visibility.Visible;
                MainProgressBar.Value = 0;
            });
        }

        private void HideProgressBar()
        {
            Dispatcher.Invoke(() =>
            {
                ProgressPanel.Visibility = Visibility.Collapsed;
                MainProgressBar.Value = 0;
            });
        }

        private void SetProgress(double v)
        {
            Dispatcher.Invoke(() =>
            {
                v = Math.Clamp(v, 0, 100);
                MainProgressBar.Value = v;
                ProgressPanel.Visibility = Visibility.Visible;
            });
        }

        private void DisableButtons() => SetButtons(false);

        private void EnableButtons() => SetButtons(true);

        private void SetButtons(bool state)
        {
            BtnCheckLatest.IsEnabled = state;
            BtnInstallDownloaded.IsEnabled = state;
            BtnPortable.IsEnabled = state;
            BtnInstallKit.IsEnabled = state;
            BtnOpenEmulatorFolder.IsEnabled = state;
            BtnLaunchEmulator.IsEnabled = state;
            BtnAutoSetup.IsEnabled = state;
        }

        #endregion

        #region Utilitaires

        private string FormatReleaseDate(string? iso)
        {
            if (DateTimeOffset.TryParse(iso,
                CultureInfo.InvariantCulture,
                DateTimeStyles.RoundtripKind,
                out var dto))
                return dto.ToLocalTime().ToString(CultureInfo.CurrentCulture);

            return iso ?? "Inconnue";
        }

        private static void CopyDir(string src, string dst)
        {
            Directory.CreateDirectory(dst);

            foreach (var dir in Directory.GetDirectories(src, "*", SearchOption.AllDirectories))
            {
                var rel = dir.Substring(src.Length)
                             .TrimStart(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                Directory.CreateDirectory(Path.Combine(dst, rel));
            }

            foreach (var file in Directory.GetFiles(src, "*.*", SearchOption.AllDirectories))
            {
                var rel = file.Substring(src.Length)
                              .TrimStart(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                var target = Path.Combine(dst, rel);
                Directory.CreateDirectory(Path.GetDirectoryName(target)!);
                File.Copy(file, target, true);
            }
        }

        private void MoveIfExists(string src, string dst)
        {
            if (File.Exists(src))
            {
                if (File.Exists(dst)) File.Delete(dst);
                File.Move(src, dst);
                AppendLog($"✔ {Path.GetFileName(dst)} installé");
            }
        }

        #endregion

        #region Téléchargement

        private async Task DownloadFileWithProgressAsync(string url, string dest)
        {
            ShowProgressBar();
            SetProgress(0);

            using var response = await _httpClient.GetAsync(url,
                HttpCompletionOption.ResponseHeadersRead);
            response.EnsureSuccessStatusCode();

            long? total = response.Content.Headers.ContentLength;

            await using var input = await response.Content.ReadAsStreamAsync();
            await using var output = File.Create(dest);

            byte[] buffer = new byte[8192];
            int read;
            long totalRead = 0;

            while ((read = await input.ReadAsync(buffer, 0, buffer.Length)) > 0)
            {
                await output.WriteAsync(buffer, 0, read);
                totalRead += read;

                if (total.HasValue && total.Value > 0)
                {
                    SetProgress(totalRead * 100.0 / total.Value);
                }
                else
                {
                    SetProgress(50);
                }
            }

            SetProgress(100);
        }

        #endregion

        #region Dernière version Canary (bouton manuel)

        private async void BtnCheckLatest_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DisableButtons();
                ShowProgressBar();
                AppendLog("Recherche de la dernière version Canary...");

                using var response = await _httpClient.GetAsync(CanaryReleasesApiUrl);
                response.EnsureSuccessStatusCode();

                var json = await response.Content.ReadAsStringAsync();
                using var doc = JsonDocument.Parse(json);
                var root = doc.RootElement;

                if (root.ValueKind != JsonValueKind.Array || root.GetArrayLength() == 0)
                    throw new Exception("Aucune release trouvée.");

                var latest = root[0];
                string version = latest.GetProperty("name").GetString() ?? "Inconnue";
                string? dateIso = latest.GetProperty("released_at").GetString();
                string dateLocal = FormatReleaseDate(dateIso);

                TxtVersionName.Text = version;
                TxtVersionDate.Text = dateLocal;

                AppendLog($"Version trouvée : {version} ({dateLocal})");

                var assets = latest.GetProperty("assets").GetProperty("links")
                    .EnumerateArray();

                var winAsset = assets.FirstOrDefault(a =>
                    a.GetProperty("name").GetString()?
                    .EndsWith("win_x64.zip", StringComparison.OrdinalIgnoreCase) == true);

                if (winAsset.ValueKind == JsonValueKind.Undefined)
                    throw new Exception("Archive Windows x64 introuvable.");

                string fileName = winAsset.GetProperty("name").GetString()!;
                string url = winAsset.TryGetProperty("direct_asset_url", out var da)
                    ? da.GetString()!
                    : winAsset.GetProperty("url").GetString()!;

                string destZip = Path.Combine(_versionsDir, fileName);

                if (File.Exists(destZip))
                {
                    MessageBox.Show(
                        "Cette version est déjà téléchargée.",
                        "Information",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                    AppendLog("Version déjà présente.");
                    return;
                }

                if (MessageBox.Show(
                    $"Télécharger {fileName} ?",
                    "Téléchargement",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question) != MessageBoxResult.Yes)
                {
                    AppendLog("Téléchargement annulé.");
                    return;
                }

                await DownloadFileWithProgressAsync(url, destZip);
                AppendLog("Téléchargement OK -> Installation...");
                await InstallArchiveAsync(destZip);

                AppendLog("✔ Installation de la dernière version Canary terminée !");
            }
            catch (Exception ex)
            {
                AppendLog("Erreur : " + ex.Message);
                MessageBox.Show(ex.Message, "Erreur",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                HideProgressBar();
                EnableButtons();
            }
        }

        #endregion

        #region Installation Emulateur

        private async Task InstallArchiveAsync(string zipPath)
        {
            if (string.IsNullOrWhiteSpace(zipPath))
                throw new ArgumentException("zipPath est vide.", nameof(zipPath));

            string installPath = await GetInstallPathOrAskAsync();

            // On repart sur un Temp propre
            if (Directory.Exists(_tempDir))
                Directory.Delete(_tempDir, true);
            Directory.CreateDirectory(_tempDir);

            AppendLog("Décompression...");
            ZipFile.ExtractToDirectory(zipPath, _tempDir, true);

            string? publish = Directory.GetDirectories(_tempDir, "publish",
                SearchOption.AllDirectories).FirstOrDefault();

            if (publish == null)
                throw new Exception("Répertoire 'publish' introuvable.");

            string emulator = Path.Combine(installPath, "Emulateur");

            // 🔴 IMPORTANT : on NE supprime PLUS le dossier Emulateur
            // On s'assure simplement qu'il existe
            Directory.CreateDirectory(emulator);

            AppendLog("Installation en cours (écrasement des fichiers existants)...");
            CopyDir(publish, emulator);   // File.Copy(..., overwrite: true) dans CopyDir
            AppendLog("✔ Emulateur mis à jour sans supprimer le répertoire.");
        }

        #endregion

        #region Installer version locale

        private async void BtnInstallDownloaded_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DisableButtons();

                string[] files = Directory.GetFiles(_versionsDir, "*.zip");

                if (files.Length == 0)
                {
                    MessageBox.Show(
                        "Aucune version téléchargée.",
                        "Information",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                    AppendLog("Aucune archive trouvée dans 'Versions Précédentes'.");
                    return;
                }

                var win = new SelectVersionWindow(files) { Owner = this };

                if (win.ShowDialog() == true && !string.IsNullOrEmpty(win.SelectedArchivePath))
                {
                    await InstallArchiveAsync(win.SelectedArchivePath);
                    AppendLog("✔ Installation de l'archive sélectionnée terminée.");
                }
                else
                {
                    AppendLog("Installation annulée par l'utilisateur.");
                }
            }
            catch (Exception ex)
            {
                AppendLog("Erreur : " + ex.Message);
                MessageBox.Show(ex.Message, "Erreur",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                EnableButtons();
            }
        }

        #endregion

        #region Mode portable

        private async void BtnPortable_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DisableButtons();
                AppendLog("Gestion du mode portable...");

                string install = await GetInstallPathOrAskAsync();
                string emulator = Path.Combine(install, "Emulateur");

                if (!Directory.Exists(emulator))
                {
                    MessageBox.Show(
                        "Le répertoire 'Emulateur' n'existe pas dans le chemin d'installation.",
                        "Information",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                    AppendLog("Répertoire 'Emulateur' introuvable.");
                    return;
                }

                string portable = Path.Combine(emulator, "portable");

                if (Directory.Exists(portable))
                {
                    AppendLog("Mode portable déjà actif (dossier 'portable' présent).");

                    var keep = MessageBox.Show(
                        "Le mode portable est déjà actif (dossier 'portable' présent)." +
                        Environment.NewLine +
                        "Souhaitez-vous le conserver ?",
                        "Mode portable",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Question);

                    if (keep == MessageBoxResult.Yes)
                    {
                        AppendLog("Mode portable conservé.");
                        return;
                    }

                    var confirm = MessageBox.Show(
                        "ATTENTION : la désactivation du mode portable va supprimer les configurations et les sauvegardes" +
                        " contenues dans le dossier 'portable'." +
                        Environment.NewLine +
                        "Êtes-vous sûr de vouloir continuer ?",
                        "Confirmer la désactivation du mode portable",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Warning);

                    if (confirm == MessageBoxResult.Yes)
                    {
                        Directory.Delete(portable, true);
                        AppendLog("Mode portable désactivé (dossier 'portable' supprimé).");
                        MessageBox.Show(
                            "Mode portable désactivé. Les configurations et sauvegardes du dossier 'portable' ont été supprimées.",
                            "Information",
                            MessageBoxButton.OK,
                            MessageBoxImage.Information);
                    }
                    else
                    {
                        AppendLog("Suppression du mode portable annulée par l'utilisateur.");
                    }
                }
                else
                {
                    Directory.CreateDirectory(portable);
                    AppendLog("Mode portable activé (dossier 'portable' créé).");
                    MessageBox.Show(
                        "Mode portable activé.",
                        "Information",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                AppendLog("Erreur : " + ex.Message);
                MessageBox.Show(
                    ex.Message,
                    "Erreur",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
            finally
            {
                EnableButtons();
            }
        }

        #endregion

        #region Kits

        private async void BtnInstallKit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DisableButtons();
                ShowProgressBar();

                AppendLog("Gestion des Kits...");

                string[] kits = Directory.GetFiles(_kitsDir, "*.zip");

                if (kits.Length == 0)
                {
                    var ask = MessageBox.Show(
                        "Aucun Kit n'est présent dans le dossier 'Kits'." +
                        Environment.NewLine +
                        "Souhaitez-vous télécharger le Kit Firmware-21 maintenant ?",
                        "Kits",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Question);

                    if (ask != MessageBoxResult.Yes)
                    {
                        AppendLog("Téléchargement du Kit annulé.");
                        return;
                    }

                    string destZip = Path.Combine(_kitsDir, "Firmware-21.zip");
                    AppendLog("Téléchargement du Kit Firmware-21...");
                    await DownloadFileWithProgressAsync(KitDownloadUrl, destZip);

                    AppendLog("Décompression du Kit dans 'Temp'...");
                    if (Directory.Exists(_tempDir))
                        Directory.Delete(_tempDir, true);
                    Directory.CreateDirectory(_tempDir);

                    ZipFile.ExtractToDirectory(destZip, _tempDir, true);
                    AppendLog("✔ Kit décompressé dans le dossier 'Temp'.");

                    await ProcessKitInTempAsync();
                }
                else
                {
                    AppendLog("Kits trouvés. Sélection d'un Kit à installer...");

                    var selectWindow = new SelectVersionWindow(kits) { Owner = this };

                    if (selectWindow.ShowDialog() == true &&
                        !string.IsNullOrEmpty(selectWindow.SelectedArchivePath))
                    {
                        string selectedZip = selectWindow.SelectedArchivePath;
                        AppendLog($"Décompression du Kit : {Path.GetFileName(selectedZip)} dans 'Temp'...");

                        if (Directory.Exists(_tempDir))
                            Directory.Delete(_tempDir, true);
                        Directory.CreateDirectory(_tempDir);

                        ZipFile.ExtractToDirectory(selectedZip, _tempDir, true);
                        AppendLog("✔ Kit décompressé dans le dossier 'Temp'.");

                        await ProcessKitInTempAsync();
                    }
                    else
                    {
                        AppendLog("Installation du Kit annulée par l'utilisateur.");
                    }
                }
            }
            catch (Exception ex)
            {
                AppendLog("Erreur Kits : " + ex.Message);
                MessageBox.Show(
                    ex.Message,
                    "Erreur Kits",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
            finally
            {
                HideProgressBar();
                EnableButtons();
            }
        }

        private async Task ProcessKitInTempAsync()
        {
            try
            {
                string tempBisDir = Path.Combine(_tempDir, "bis");
                if (!Directory.Exists(tempBisDir))
                {
                    AppendLog("Répertoire 'bis' introuvable dans Temp. Aucun traitement de Kit effectué.");
                    return;
                }

                string install = await GetInstallPathOrAskAsync();
                string emulatorDir = Path.Combine(install, "Emulateur");
                if (!Directory.Exists(emulatorDir))
                {
                    AppendLog("Répertoire 'Emulateur' introuvable. Impossible d'appliquer le Kit.");
                    return;
                }

                string portableDir = Path.Combine(emulatorDir, "portable");
                Directory.CreateDirectory(portableDir);
                AppendLog("Répertoire portable : " + portableDir);

                // Config.json
                string configSrc = Path.Combine(tempBisDir, "Config.json");
                if (!File.Exists(configSrc))
                {
                    configSrc = Path.Combine(tempBisDir, "Config.JSON");
                }

                if (File.Exists(configSrc))
                {
                    string configDst = Path.Combine(portableDir, "Config.json");
                    if (File.Exists(configDst)) File.Delete(configDst);
                    File.Move(configSrc, configDst);
                    AppendLog("Config.json déplacé dans le répertoire portable.");
                }
                else
                {
                    AppendLog("Config.json introuvable dans le Kit.");
                }

                // System + keys
                string systemDir = Path.Combine(portableDir, "System");
                Directory.CreateDirectory(systemDir);

                string k1Src = Path.Combine(tempBisDir, "k1.dll");
                if (File.Exists(k1Src))
                {
                    string prodDst = Path.Combine(systemDir, "prod.keys");
                    if (File.Exists(prodDst)) File.Delete(prodDst);
                    File.Move(k1Src, prodDst);
                    AppendLog("k1.dll déplacé et renommé en prod.keys.");
                }
                else
                {
                    AppendLog("k1.dll introuvable dans le Kit.");
                }

                string k2Src = Path.Combine(tempBisDir, "k2.dll");
                if (File.Exists(k2Src))
                {
                    string titleDst = Path.Combine(systemDir, "title.keys");
                    if (File.Exists(titleDst)) File.Delete(titleDst);
                    File.Move(k2Src, titleDst);
                    AppendLog("k2.dll déplacé et renommé en title.keys.");
                }
                else
                {
                    AppendLog("k2.dll introuvable dans le Kit.");
                }

                // Déplacement du répertoire bis dans Emulateur\portable\bis
                string portableBisDir = Path.Combine(portableDir, "bis");

                if (Directory.Exists(portableBisDir))
                {
                    AppendLog("Un répertoire 'bis' existe déjà dans portable, il sera remplacé.");
                    Directory.Delete(portableBisDir, true);
                }

                string srcRoot = Path.GetPathRoot(tempBisDir) ?? "";
                string dstRoot = Path.GetPathRoot(portableBisDir) ?? "";

                if (!string.Equals(srcRoot, dstRoot, StringComparison.OrdinalIgnoreCase))
                {
                    AppendLog("Volumes différents → copie du répertoire 'bis' vers portable...");
                    CopyDir(tempBisDir, portableBisDir);
                    Directory.Delete(tempBisDir, true);
                }
                else
                {
                    Directory.Move(tempBisDir, portableBisDir);
                }

                AppendLog("✔ Répertoire 'bis' déplacé dans le répertoire portable.");
                AppendLog("✔ Traitement du Kit terminé (Config + keys + bis installés en mode portable).");

                if (Directory.Exists(_tempDir))
                {
                    Directory.Delete(_tempDir, true);
                    AppendLog("Dossier 'Temp' nettoyé après traitement du Kit.");
                }
            }
            catch (Exception ex)
            {
                AppendLog("Erreur lors du traitement du Kit : " + ex.Message);
                MessageBox.Show(
                    ex.Message,
                    "Erreur Kit",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        #endregion

        #region Ouvrir le dossier Emulateur

        private async void BtnOpenEmulatorFolder_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string install = await GetInstallPathOrAskAsync();
                string emulatorDir = Path.Combine(install, "Emulateur");

                if (!Directory.Exists(emulatorDir))
                {
                    MessageBox.Show(
                        "Le répertoire 'Emulateur' est introuvable.",
                        "Information",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                    AppendLog("Ouverture du dossier Emulateur impossible (dossier introuvable).");
                    return;
                }

                Process.Start("explorer.exe", emulatorDir);
                AppendLog("Dossier Emulateur ouvert dans l'explorateur.");
            }
            catch (Exception ex)
            {
                AppendLog("Erreur ouverture dossier Emulateur : " + ex.Message);
                MessageBox.Show(
                    ex.Message,
                    "Erreur",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        #endregion

        #region Lancer l'émulateur

        private async void BtnLaunchEmulator_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string install = await GetInstallPathOrAskAsync();
                string emulatorDir = Path.Combine(install, "Emulateur");

                if (!Directory.Exists(emulatorDir))
                {
                    MessageBox.Show(
                        "Le dossier 'Emulateur' est introuvable. Installe d'abord une version de Ryujinx.",
                        "Information",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                    AppendLog("Lancement annulé : répertoire Emulateur introuvable.");
                    return;
                }

                string exePath = Path.Combine(emulatorDir, "Ryujinx.exe");
                if (!File.Exists(exePath))
                {
                    string? firstExe = Directory.GetFiles(emulatorDir, "*.exe").FirstOrDefault();
                    if (!string.IsNullOrEmpty(firstExe))
                        exePath = firstExe;
                }

                if (!File.Exists(exePath))
                {
                    MessageBox.Show(
                        "Impossible de trouver Ryujinx.exe dans le dossier Emulateur.",
                        "Information",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                    AppendLog("Ryujinx.exe introuvable pour le lancement.");
                    return;
                }

                var psi = new ProcessStartInfo(exePath)
                {
                    WorkingDirectory = Path.GetDirectoryName(exePath)!,
                    UseShellExecute = true
                };

                Process proc = Process.Start(psi)!;
                AppendLog("Lancement de l'émulateur Ryujinx.");

                await CenterProcessWindowAsync(proc);
            }
            catch (Exception ex)
            {
                AppendLog("Erreur lors du lancement de l'émulateur : " + ex.Message);
                MessageBox.Show(
                    ex.Message,
                    "Erreur lancement",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        #endregion

        #region Effacer le journal

        private void BtnClearLog_Click(object sender, RoutedEventArgs e)
        {
            TxtLog.Clear();
        }

        #endregion

        #region Auto-setup (Tout installer et lancer)

        private async void BtnAutoSetup_Click(object sender, RoutedEventArgs e)
        {
            await AutoSetupEverythingAsync();
        }

        private async Task AutoSetupEverythingAsync()
        {
            try
            {
                DisableButtons();
                ShowProgressBar();
                AppendLog("[AUTO] Démarrage de l'installation automatique Ryujinx...");

                // 🔁 Toujours redemander le dossier d'installation
                AppendLog("[AUTO] Sélection du dossier d'installation...");
                SelectInstallPathWithDialog();                 // ouvre la boîte de dialogue
                string install = await GetInstallPathOrAskAsync(); // relit le chemin choisi
                AppendLog($"[AUTO] Dossier d'installation sélectionné : {install}");

                // 1) Installer / mettre à jour l'émulateur
                await AutoInstallLatestCanaryAsync();

                // 2) Installer le Kit
                await AutoInstallKitAsync();

                // 3) Lancer Ryujinx
                AppendLog("[AUTO] Lancement de l'émulateur Ryujinx...");
                await Dispatcher.InvokeAsync(() => BtnLaunchEmulator_Click(this, new RoutedEventArgs()));

                AppendLog("[AUTO] ✔ Séquence automatique terminée.");
            }
            catch (Exception ex)
            {
                AppendLog("[AUTO][ERREUR] " + ex.Message);
                MessageBox.Show(
                    ex.Message,
                    "Erreur installation automatique",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
            finally
            {
                HideProgressBar();
                EnableButtons();
            }
        }

        private async Task AutoInstallLatestCanaryAsync()
        {
            AppendLog("[AUTO] Recherche de la dernière version Canary...");

            using var response = await _httpClient.GetAsync(CanaryReleasesApiUrl);
            response.EnsureSuccessStatusCode();

            var json = await response.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;

            if (root.ValueKind != JsonValueKind.Array || root.GetArrayLength() == 0)
                throw new Exception("Aucune release Canary trouvée.");

            var latest = root[0];
            string version = latest.GetProperty("name").GetString() ?? "Inconnue";
            string? dateIso = latest.GetProperty("released_at").GetString();
            string dateLocal = FormatReleaseDate(dateIso);

            TxtVersionName.Text = version;
            TxtVersionDate.Text = dateLocal;

            AppendLog($"[AUTO] Dernière Canary : {version} ({dateLocal})");

            var assets = latest.GetProperty("assets").GetProperty("links")
                .EnumerateArray();

            var winAsset = assets.FirstOrDefault(a =>
                a.GetProperty("name").GetString()?
                .EndsWith("win_x64.zip", StringComparison.OrdinalIgnoreCase) == true);

            if (winAsset.ValueKind == JsonValueKind.Undefined)
                throw new Exception("Archive Windows x64 introuvable.");

            string fileName = winAsset.GetProperty("name").GetString()!;
            string url = winAsset.TryGetProperty("direct_asset_url", out var da)
                ? da.GetString()!
                : winAsset.GetProperty("url").GetString()!;

            string destZip = Path.Combine(_versionsDir, fileName);

            if (File.Exists(destZip))
            {
                AppendLog("[AUTO] Archive déjà présente → installation directe...");
                await InstallArchiveAsync(destZip);
                AppendLog("[AUTO] ✔ Emulateur mis à jour depuis l'archive existante.");
            }
            else
            {
                AppendLog($"[AUTO] Téléchargement de {fileName}...");
                await DownloadFileWithProgressAsync(url, destZip);
                AppendLog("[AUTO] Téléchargement OK → Installation...");
                await InstallArchiveAsync(destZip);
                AppendLog("[AUTO] ✔ Emulateur mis à jour depuis la dernière Canary.");
            }
        }

        private async Task AutoInstallKitAsync()
        {
            AppendLog("[AUTO] Préparation de l'installation du Kit...");

            string[] kits = Directory.GetFiles(_kitsDir, "*.zip");
            string zipToUse;

            if (kits.Length == 0)
            {
                zipToUse = Path.Combine(_kitsDir, "Firmware-21.zip");
                AppendLog("[AUTO] Aucun Kit local → téléchargement automatique de Firmware-21...");
                await DownloadFileWithProgressAsync(KitDownloadUrl, zipToUse);
            }
            else
            {
                string? firmware = kits.FirstOrDefault(p =>
                    Path.GetFileName(p).Contains("Firmware-21", StringComparison.OrdinalIgnoreCase));

                if (firmware != null)
                {
                    zipToUse = firmware;
                }
                else
                {
                    zipToUse = kits.OrderByDescending(File.GetCreationTimeUtc).First();
                }

                AppendLog($"[AUTO] Kit sélectionné : {Path.GetFileName(zipToUse)}");
            }

            if (Directory.Exists(_tempDir))
                Directory.Delete(_tempDir, true);
            Directory.CreateDirectory(_tempDir);

            AppendLog("[AUTO] Décompression du Kit dans 'Temp'...");
            ZipFile.ExtractToDirectory(zipToUse, _tempDir, true);
            AppendLog("[AUTO] Traitement du Kit...");
            await ProcessKitInTempAsync();
            AppendLog("[AUTO] ✔ Kit appliqué.");
        }

        #endregion
    }
}
